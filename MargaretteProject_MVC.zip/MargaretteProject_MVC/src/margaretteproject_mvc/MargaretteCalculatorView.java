/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package margaretteproject_mvc;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
public class MargaretteCalculatorView  extends JFrame {
    JFrame frame; 
   JTextField textfield = new JTextField();
   JButton[] numberButtons = new JButton[10];
   JButton addButton,subButton,mulButton,divButton;
   JButton cButton, equButton, saveButton, viewButton, clearButton;
   JPanel panel;
    
    public Font myFont = new Font("Arial Black",Font.BOLD,30);
	
    int num1=0,num2=0,result=0;
    char operator; 
    MargaretteCalculatorView(){
        
                this.setTitle("Calculator");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(420, 550);
		this.setLayout(null);
		
		
		textfield.setBounds(50, 25, 300, 50);
		textfield.setFont(myFont);
		textfield.setEditable(false);
		
		addButton = new JButton("+");
		subButton = new JButton("-");
		mulButton = new JButton("*");
		divButton = new JButton("/");
		cButton = new JButton("C");
		equButton = new JButton("=");
		saveButton = new JButton("Save");
                clearButton = new JButton("Clear");
		viewButton = new JButton("View");
		
		
		
		
		for(int i =0;i<10;i++) {
			 numberButtons[i] = new JButton(String.valueOf(i));
		}
		
		clearButton.setBounds(150,430,100,50);
		saveButton.setBounds(50,430,100,50);
		viewButton.setBounds(250,430,100,50);
		
		panel = new JPanel();
		panel.setBounds(50, 100, 300, 300);
		panel.setLayout(new GridLayout(4,4,10,10));

		panel.add(numberButtons[1]);
		panel.add(numberButtons[2]);
		panel.add(numberButtons[3]);
		panel.add(addButton);
		panel.add(numberButtons[4]);
		panel.add(numberButtons[5]);
		panel.add(numberButtons[6]);
		panel.add(subButton);
		panel.add(numberButtons[7]);
		panel.add(numberButtons[8]);
		panel.add(numberButtons[9]);
		panel.add(mulButton);
		panel.add(cButton);
		panel.add(numberButtons[0]);
		panel.add(equButton);
		panel.add(divButton);
		
		this.add(panel);
		
		this.add(saveButton);
		this.add(viewButton);
                this.add(clearButton);
		this.add(textfield);
		this.setVisible(true);
	}
  
    
}
