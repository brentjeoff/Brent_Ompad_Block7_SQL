
package margaretteproject_mvc;


public class MargaretteMain {
    public static void main(String[] args) {
    MargaretteCalculatorView view = new MargaretteCalculatorView();
        MargaretteDbConnection model = new MargaretteDbConnection();
        MargaretteCalculatorController cont = new MargaretteCalculatorController(view, model); 

        view.setVisible(true);
    
    }
}
