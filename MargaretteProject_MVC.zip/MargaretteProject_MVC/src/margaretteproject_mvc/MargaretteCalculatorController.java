/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package margaretteproject_mvc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
public class MargaretteCalculatorController {
     public MargaretteCalculatorView view;
    public MargaretteDbConnection model;
    
    public int num1, num2;
    public String op;
    int Result; 
    public MargaretteCalculatorController(MargaretteCalculatorView view, MargaretteDbConnection model) {
        this.view = view;
        this.model = model;
        
        for (int i = 0; i < 10; i++) {
            int num = i;
            view.numberButtons[i].addActionListener(e ->
                view.textfield.setText(view.textfield.getText() + num)
            );
        }
        view.addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Integer.parseInt(view.textfield.getText());
        view.textfield.setText("");
        op="+";
            }
        });
        view.subButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Integer.parseInt(view.textfield.getText());
        view.textfield.setText("");
        op="-";
            }
        });
        
        view.mulButton.addActionListener(new ActionListener () {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Integer.parseInt(view.textfield.getText());
        view.textfield.setText("");
        op="*";
            }
        });
        view.divButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              num1 = Integer.parseInt(view.textfield.getText());
        view.textfield.setText("");
        op="/";
            }
        });
        
     view.equButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            num2 = Integer.parseInt(view.textfield.getText());
       if (op == "+") {
        Result = num1 + num2; 
        view.textfield.setText(String. valueOf(Result));    
       } else if (op == "-") {
        Result = num1 - num2; 
        view.textfield.setText(String. valueOf(Result));
       } else if (op == "*") {
        Result = num1 * num2; 
        view.textfield.setText(String. valueOf(Result));
       } else if (op == "/") {
        Result = num1 / num2; 
        view.textfield.setText(String. valueOf(Result));
       }     
            }
            
            
            });

        // Clear
        view.cButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              view.textfield.setText("");
            }
        });
        view.saveButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              
              
        double value =  Double.parseDouble(view.textfield.getText());
         MargaretteCalculatorRecords.addResult(value);
          int text = Integer.parseInt(view.textfield.getText());
                try {
                    model.calculateRecords(text);
                } catch (ClassNotFoundException ex) {
                    System.getLogger(MargaretteCalculatorController.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
                }
            }
            
    
            
        });
        
         view.clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    model.clearRecords();
                     //double value =  Double.parseDouble(view.textfield.getText());
                   //  CalculatorRecords.addResult(value);
                    int rowIndex = Integer.parseInt(view.textfield.getText());
                    MargaretteCalculatorRecords.deleteRow(rowIndex);
                } catch (SQLException ex) {
                    System.getLogger(MargaretteCalculatorController.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
                }
            }
         
                    
            
        });
          view.viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 MargaretteCalculatorRecords recordTable = new MargaretteCalculatorRecords();
        recordTable.setVisible(true);
        recordTable.pack();
        recordTable.setLocationRelativeTo(null);
        recordTable.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        double value =  Double.parseDouble(view.textfield.getText());
         MargaretteCalculatorRecords.addResult(value);
            }
            
            
          });
          
          
    }
}
