/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package margaretteproject_mvc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
public class MargaretteCalculatorRecords  extends JFrame{
    public static DefaultTableModel model;
public static JTable table;

    static void addResult(double value) {
        model.addRow(new Object[]{value});
    }
    static void deleteRow(int rowIndex) {    
        model.setRowCount(0);
    } 
    
    public MargaretteCalculatorRecords() {
        setTitle("Records");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
       model = new DefaultTableModel(new String[]{"RECORDS"}, 0);
        table = new JTable(model);
       model.setRowCount(0); // clear table

       
        JScrollPane scrollPane = new JScrollPane(table);
        
        
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);
    }
    public JTable getTable() {
        return table;
    }
    
}
